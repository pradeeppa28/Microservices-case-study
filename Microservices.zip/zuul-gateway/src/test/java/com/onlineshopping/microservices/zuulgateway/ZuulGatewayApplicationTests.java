package com.onlineshopping.microservices.zuulgateway;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulGatewayApplicationTests {

	
	void contextLoads() {
	}

}
