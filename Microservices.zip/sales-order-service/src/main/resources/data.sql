insert into customer_sos (cust_id,cust_first_name,cust_last_name,cust_email_id) values (1111,'John','Ryan','ab1@xyz.com')
insert into customer_sos (cust_id,cust_first_name,cust_last_name,cust_email_id) values (2222,'Ryan','Dave','ab2@xyz.com')
insert into customer_sos (cust_id,cust_first_name,cust_last_name,cust_email_id) values (3333,'Greer','Jill','ab3@xyz.com')
insert into customer_sos (cust_id,cust_first_name,cust_last_name,cust_email_id) values (4444,'Jim','Donald','ab4@xyz.com')