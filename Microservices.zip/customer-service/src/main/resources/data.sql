insert into customer (cust_id,email_id,first_name,last_name) values (1111,'ab1@xyz.com','John','Donald')
insert into customer (cust_id,email_id,first_name,last_name) values (2222,'ab2@xyz.com','Tim','Gordon')
insert into customer (cust_id,email_id,first_name,last_name) values (3333,'ab3@xyz.com','Lynn','Ols')
insert into customer (cust_id,email_id,first_name,last_name) values (4444,'ab4@xyz.com','Mike','Dany')