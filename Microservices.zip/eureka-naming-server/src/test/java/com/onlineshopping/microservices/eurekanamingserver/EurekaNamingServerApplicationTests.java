package com.onlineshopping.microservices.eurekanamingserver;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaNamingServerApplicationTests {

	
	void contextLoads() {
	}

}
