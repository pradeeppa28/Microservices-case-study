insert into item (item_id,item_name,item_desc,item_price) values (111,'Pen','Red Blue or Black',5.33)
insert into item (item_id,item_name,item_desc,item_price) values (222,'Book','200 Pages',18.36)
insert into item (item_id,item_name,item_desc,item_price) values (333,'Pencil','HB bold',2.36)
insert into item (item_id,item_name,item_desc,item_price) values (444,'Marker','Red Blue or Black',23.22)